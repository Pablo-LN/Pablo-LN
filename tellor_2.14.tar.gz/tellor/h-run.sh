#!/usr/bin/env bash

CUSTOM_DIR=`dirname $0`
cd $CUSTOM_DIR

. h-manifest.conf

CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

./TellorMiner mine 2>&1 | tee $CUSTOM_LOG_BASENAME.log
